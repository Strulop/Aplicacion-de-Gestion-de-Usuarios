package com.euroformac.practica_6

import android.content.ContentValues
import android.content.Context
import android.database.Cursor
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

class DatabaseHelper(context: Context) : SQLiteOpenHelper(context, DATABASE_NAME, null, DATABASE_VERSION) {

    companion object {
        private const val DATABASE_NAME = "mi_base_de_datos.db"
        private const val DATABASE_VERSION = 1
    }

    override fun onCreate(db: SQLiteDatabase?) {
        // No se implementa porque la base ya está pre-creada
    }

    override fun onUpgrade(db: SQLiteDatabase?, oldVersion: Int, newVersion: Int) {
        // Manejo de actualizaciones si la base de datos cambia
    }

    fun login(usuario: String, contraseña: String): Boolean {
        val db = this.readableDatabase
        val cursor: Cursor = db.rawQuery(
            "SELECT * FROM usuarios WHERE email = ? AND password = ?",
            arrayOf(usuario, contraseña)
        )
        val isValid = cursor.count > 0
        cursor.close()
        return isValid
    }

    fun register(usuario: String, contraseña: String): Boolean {
        val db = this.writableDatabase
        val values = ContentValues()
        values.put("email", usuario)
        values.put("password", contraseña)

        return try {
            db.insert("usuarios", null, values) > 0
        } catch (e: Exception) {
            false
        }
    }
}
