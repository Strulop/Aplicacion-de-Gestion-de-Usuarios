package com.euroformac.practica_6

import android.content.Context
import java.io.File
import java.io.FileOutputStream
import java.io.IOException

object DatabaseCopier {
    fun copyDatabase(context: Context) {
        val dbFile = File(context.getDatabasePath("mi_base_de_datos.db").path)
        if (!dbFile.exists()) {
            try {
                val inputStream = context.assets.open("mi_base_de_datos.db")
                val outputStream = FileOutputStream(dbFile)

                val buffer = ByteArray(1024)
                var length: Int
                while (inputStream.read(buffer).also { length = it } > 0) {
                    outputStream.write(buffer, 0, length)
                }

                outputStream.flush()
                outputStream.close()
                inputStream.close()
            } catch (e: IOException) {
                e.printStackTrace()
            }
        }
    }
}